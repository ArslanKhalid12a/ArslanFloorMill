<?php 
	$con=mysqli_connect("localhost","root","","flour_mils");
	
 

	$email_id = $_POST["email_id"]; 

	$password = $_POST["password"];
 

	$sql = "INSERT INTO employee  ( email_id , password) VALUES ('$email_id','$password')";
	$result = mysqli_query( $con,$sql );
	
	if($result) {
		echo "registered successfully";
	}
	else {
		echo "some error occured";
	}
?>