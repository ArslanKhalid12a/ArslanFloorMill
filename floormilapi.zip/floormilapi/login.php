<?php

$conn=mysqli_connect("localhost","root","");
mysqli_select_db($conn,"flour_mils");

	if($_SERVER['REQUEST_METHOD'] == 'POST')
	{
		// posting variables to..
		$email_id=$_POST['email_id'];
		$password=$_POST['password'];

		$que=mysqli_query($conn,"select * from  employee where email_id ='$email_id' and password='$password'");
		$row=mysqli_num_rows($que);

		if($row)
		{

	           $result["success"] = "1";
		       $result["message"] = "Successful";

		       // Encoding result into Json
		       echo json_encode($result);
	        	
	        }

		else
			{

		$result["success"] = "0";
		$result["message"] = "Incorrect username or password";

		//Encoding the result to json
		 echo json_encode($result);
				
			}
	}

?>
