<?php
$conn=mysql_connect("localhost","root","");
mysql_select_db("flour_mils",$conn);

$qry="select * from cart1";
$raw=mysql_query($qry);
while($res=mysql_fetch_array($raw))
{
	$data[]=$res;
}
print(json_encode($data));
?>